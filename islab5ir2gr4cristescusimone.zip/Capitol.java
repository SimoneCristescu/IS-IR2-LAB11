package lab5;

import java.util.Vector;

public class Capitol extends Header{
	private String rezumat;
	private Vector<Sectiune> sectiuni = new Vector();

	public Capitol(String titlu, int numar, String rezumat) {
		super(titlu, numar);
		this.rezumat = rezumat;
	}

	public String getRezumat() {
		return rezumat;
	}

	public void setRezumat(String rezumat) {
		this.rezumat = rezumat;
	}
	
	//Metoda pentru ca unui capitol sa i se adauge o sectiune
	public void addParte(Sectiune s) {
		sectiuni.add(s);
	}
}
