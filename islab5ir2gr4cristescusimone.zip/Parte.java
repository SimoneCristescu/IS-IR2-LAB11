package lab5;

import java.util.Vector;

public class Parte extends Header{
	private Vector<Capitol> capitole = new Vector();

	public Parte(String titlu, int numar) {
		super(titlu, numar);
	}
	
	//Metoda pentru ca unei parti sa i se adauge un capitol
	public void addCapitol(Capitol c) {
		capitole.add(c);
	}
}
