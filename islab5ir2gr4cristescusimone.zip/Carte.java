package lab5;

import java.sql.Date;
import java.util.Vector;

public class Carte {
	private String editor;
	private Date dataPublicare;
	private String ISBN;
	private Vector<Parte> parti = new Vector();
	
	public Carte(String editor, Date dataPublicare, String ISBN, Vector<Parte> parti) {
		super();
		this.editor = editor;
		this.dataPublicare = dataPublicare;
		this.ISBN = ISBN;
	}
	
	public String getEditor() {
		return editor;
	}
	public void setEditor(String editor) {
		this.editor = editor;
	}
	
	public Date getDataPublicare() {
		return dataPublicare;
	}
	public void setDataPublicare(Date dataPublicare) {
		this.dataPublicare = dataPublicare;
	}
	
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String ISBN) {
		this.ISBN = ISBN;
	}
	
	//Metoda pentru ca unei carti sa i se adauge o parte
	public void addParte(Parte p) {
		parti.add(p);
	}
}
