package lab5;

public class Sectiune extends Header{

	public Sectiune(String titlu, int numar) {
		super(titlu, numar);
	}
}
