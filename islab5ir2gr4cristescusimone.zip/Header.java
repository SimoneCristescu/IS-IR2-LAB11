package lab5;

public class Header {
	private String titlu;
	private int numar;
	
	public Header(String titlu, int numar) {
		super();
		this.titlu = titlu;
		this.numar = numar;
	}
	
	public String getTitlu() {
		return titlu;
	}
	public void setTitlu(String titlu) {
		this.titlu = titlu;
	}
	
	public int getNumar() {
		return numar;
	}
	public void setNumar(int numar) {
		this.numar = numar;
	}
}
